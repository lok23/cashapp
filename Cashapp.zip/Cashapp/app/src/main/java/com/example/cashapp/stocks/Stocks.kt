package com.example.cashapp.stocks

data class Stocks(
    val stocks: List<Stock>?
)